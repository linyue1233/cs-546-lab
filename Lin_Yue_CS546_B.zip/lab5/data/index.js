const peopleData = require('./people');
const stockData = require('./stock');

module.exports = {
    peoples: peopleData,
    stocks: stockData
};