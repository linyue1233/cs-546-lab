function validPalindrome() {
    let palidForm = document.getElementById("formSubmit");
    console.log(palidForm);
    if (palidForm) {
        let palidData = document.getElementsByName("bottomSubmit");
        palidData.addEventListener('click',(event)=>{
            if (palidData.trim() == "") {
                document.getElementById("formSubmit").innerHTML += "<p class= error-inform>  the text is an empty string, please input again </p>";
                return;
            } else {
                let lowerData = transferLower(palidData);
                // judge the string is palindrome
                let reversedData = lowerData.split("").reverse.join("");
                if (palidData === reversedData) {
                    document.getElementById("attempts").innerHTML += "<li class = s-palindrome>" + palidData + "</li>";
                } else {
                    document.getElementById('list').innerHTML += "<li class = not-palindrome>" + palidData + "</li>";
                }
    
                document.getElementById("palidromeText").value = "";
                return;
            }
        })   
    }
}

function transferLower(textstr) {
    // build pattern regex
    let pattern = /[^A-Za-z0-9]/g;
    let palidStr = x.toLowerCase().replace(pattern, '');
    return palidStr;
}